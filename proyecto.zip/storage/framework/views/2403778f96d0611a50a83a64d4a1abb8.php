<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="h4 fw-bold text-dark mb-0"> <!-- Mejor usar mb-0 -->
                <?php echo e(__('Panel Administrativo')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-5 bg-light">
        <div class="container">
            <div class="card border-0 shadow rounded-4"> <!-- rounded-4 necesita Bootstrap 5.3+ -->
                <div class="card-body p-5 text-center"> <!-- py-5 -> p-5 para padding completo -->
                    <h4 class="mb-4">Bienvenido</h4>
                    <p class="mb-5 text-muted">Gestiona las imágenes del menú y otras funciones de interes.</p>

                    <div class="d-grid gap-3 d-md-flex justify-content-md-center"> <!-- Mejor responsive -->
                        <a href="<?php echo e(route('menu.editar')); ?>" class="btn btn-primary btn-lg px-4">
                            <i class="bi bi-images me-2"></i> Editar Imágenes
                        </a>
                        <a href="<?php echo e(route('promos.editar')); ?>" class="btn btn-success btn-lg px-4">
                            <i class="bi bi-plus-circle me-2"></i> Agregar promo
                        </a>
                        <a href="#" class="btn btn-info btn-lg px-4 text-white">
                            <i class="bi bi-bar-chart-line me-2"></i> DB (Usuarios Business)
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\menu_wifi\resources\views/dashboard.blade.php ENDPATH**/ ?>