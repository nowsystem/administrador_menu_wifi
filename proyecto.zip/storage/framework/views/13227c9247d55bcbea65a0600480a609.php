<!-- resources/views/menu.blade.php -->

<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            Gestión de Imágenes del Menú
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mt-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success text-center">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($menus->isEmpty()): ?>
        <div class="col-12">
            <div class="alert alert-warning text-center mt-4">
                No tiene imágenes que editar.
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                    <?php if($menu->imagenes): ?>
        <!-- Línea modificada: agregar parámetro anti-caché -->
        <img src="data:image/jpeg;base64,<?php echo e(base64_encode($menu->imagenes)); ?>" 
                     class="card-img-top"
                     alt="Imagen <?php echo e($menu->id); ?>">
    <?php else: ?>
        <div class="card-body">
            <p class="text-muted">Sin imagen</p>
        </div>
    <?php endif; ?>
                        <div class="card-body text-center">
                            <h5 class="card-title">Imagen #<?php echo e($menu->id); ?></h5>
                            <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalEditar<?php echo e($menu->id); ?>">
                                Cambiar Imagen
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Modal para editar la imagen -->
                <div class="modal fade" id="modalEditar<?php echo e($menu->id); ?>" tabindex="-1" aria-labelledby="modalEditarLabel<?php echo e($menu->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <form action="<?php echo e(route('menu.actualizar', $menu->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalEditarLabel<?php echo e($menu->id); ?>">Actualizar Imagen</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                                </div>
                                <div class="modal-body">
                                    <p class="mb-2">Imagen actual:</p>
                                    <?php if($menu->imagenes): ?>
                                        <img src="data:image/jpeg;base64,<?php echo e(base64_encode($menu->imagenes)); ?>" class="img-fluid mb-3 rounded shadow-sm">
                                    <?php else: ?>
                                        <p>No hay imagen actual.</p>
                                    <?php endif; ?>
                                    <div class="mb-3">
                                        <label for="nueva_imagen<?php echo e($menu->id); ?>" class="form-label">Selecciona una nueva imagen</label>
                                        <input type="file" name="nueva_imagen" id="nueva_imagen<?php echo e($menu->id); ?>" accept=".jpg,image/jpeg" class="form-control" required>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                  
                                    <button type="submit" class="btn btn-success">Actualizar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\menu_wifi\resources\views/menu/editar.blade.php ENDPATH**/ ?>